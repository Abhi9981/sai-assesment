1. Clone the project and extract the zip file.

2. Create a python virtual enviornment using -> python -m venv crud_venv

3. Activate the environment.

4. Install requirements using -> pip install -r requirements

5. Run following commands to setup database tables.
	a. python manage.py makemigrations
	b. python manage.py migrate

6. Run following command to run on local server.
	python manage.py runserver
